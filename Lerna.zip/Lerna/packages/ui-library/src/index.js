// ui-library/src/index.js
import { h, init } from 'snabbdom';
import eventlisteners from 'snabbdom/modules/eventlisteners';

const patch = init([eventlisteners]);

function createTemplate(state, props) {
  console.log('Rendering with state:', state);

  return h('div', {}, [
    h('h1', `Count: ${state.count}`),
    h('button', { on: { click: () => props.handleClick() } }, 'Increment'),
  ]);
}

function createReactivity(initialState) {
  let state = initialState;
  let listeners = [];
  let lifecycle = {};

  function updateState(newState) {
    state = { ...state, ...newState };
    listeners.forEach((listener) => listener(state));
    console.log('State updated:', state);
  }

  function subscribe(listener) {
    listeners.push(listener);
    return () => {
      listeners = listeners.filter((l) => l !== listener);
    };
  }

  return { state, updateState, subscribe, lifecycle };
}

function mountComponent(template, reactivity, container) {
  let vnode = template(reactivity.state, { handleClick: reactivity.updateState });

  function updateView(newState) {
    vnode = patch(vnode, template(newState, { handleClick: reactivity.updateState }));
  }

  const unsubscribe = reactivity.subscribe(updateView);

  container.appendChild(patch(container, vnode));

  if (reactivity.lifecycle && reactivity.lifecycle.mounted) {
    reactivity.lifecycle.mounted();
  }

  return () => {
    if (reactivity.lifecycle && reactivity.lifecycle.unmounted) {
      reactivity.lifecycle.unmounted();
    }
    unsubscribe();
  };
}

const initialState = { count: 0 };
const reactivity = createReactivity(initialState);

const handleClick = () => {
  reactivity.updateState({ count: reactivity.state.count + 1 });
};

const template = createTemplate;
const container = document.getElementById('app');

const unmount = mountComponent(template, reactivity, container);

setTimeout(() => {
  reactivity.updateState({ count: 10 });
}, 2000);

setTimeout(() => {
  unmount();
}, 5000);
