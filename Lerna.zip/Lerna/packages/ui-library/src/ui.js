// ui-library/src/ui.js
export { createTemplate, createReactivity, mountComponent };
